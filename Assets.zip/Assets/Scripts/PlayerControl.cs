﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour {

    public GameObject Head;
    public GameObject Body;
    public List<Vector3> Snake;
    static public int node_num = 0;

    private int moveState = ControlPanel.state;

    static public float speed = 0;
    private float xpos = 0; 
    private float zpos = 0;
    
    private void Start()
    {
        Snake.Clear();
        speed = 0.5f;
        xpos = 0;
        zpos = 0;
        InvokeRepeating("MoveHead", 0.0f, speed);
        Snake.Add(new Vector3(xpos, transform.position.y , zpos));
    }

    void Update()
    {
        moveState = ControlPanel.state;
        transform.position = Snake[0]; // 항상 머리부분의 위치값을 가져옴
        for(int i = 1; i<node_num+1; i++)
        {
            GameObject body = GameObject.Find("snake_body_" + i);
            body.transform.position = Snake[i];
        }
        
        CheckEaten();
        CheckGameOver();
    }

    public void MoveHead()
    {
        UIcontrol.movebonus++;
        if (Apple.appleEaten == true)
        {
            node_num++;
            GameObject SnakeBody = Instantiate(Body) as GameObject;
            SnakeBody.name = "snake_body_" + node_num;
            SnakeBody.transform.position = new Vector3(200,-2,0);
            Apple.appleEaten = false;
        }

        
        if (moveState == 0) // 0 1 2 3 순으로 상하좌우임
        {
            zpos += 1;
        }
        else if (moveState == 1)
        {
            zpos += -1;
        }
        else if (moveState == 2)
        {
            xpos += -1;
        }
        else if (moveState == 3)
        {
            xpos += 1;
        }
        Snake.Insert(0, new Vector3(xpos, transform.position.y, zpos)); // 헤드에 새로운 위치값을 가진 노드 삽입
        Snake.Remove(Snake[node_num+1]);
        Debug.Log(Time.timeScale);
        //Debug.Log(transform.position.x.ToString() + " " + transform.position.z.ToString() +" " + Apple.Ax.ToString() + " "+ Apple.Az.ToString());
    }

    void CheckEaten()
    {
        if(Apple.Ax == transform.position.x && Apple.Az == transform.position.z)
        {
            Apple.appleEaten = true;
            Apple.appleInstantiated = false;
        }
    }
    
    void CheckGameOver()
    {
        for (int i = 1; i<node_num+1; i++)
        {
            if(transform.position == Snake[i])
            {
                GameController.GameOver = true;
                Destroy(gameObject);
                Debug.Log(GameController.GameOver);
            }
        }
        if(transform.position.x>10 || transform.position.z > 10 || transform.position.x < -9 || transform.position.z < -9)
        {
            GameController.GameOver = true;
            Destroy(gameObject);
        }
        if(UIcontrol.sc > PlayerPrefs.GetInt("HighScore", 0))
        {
            PlayerPrefs.SetInt("HighScore", UIcontrol.sc);
        }
    }
}
