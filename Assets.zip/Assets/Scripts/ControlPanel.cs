﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlPanel : MonoBehaviour {
    public static int state = 2;

    // 상하좌우 0 1 2 3
	public void OnLeft()
    {
        state = 2;
        
    }
    public void OnRight()
    {
        state = 3;
        
    }
    public void OnUp()
    {
        state = 0;
        
    }
    public void OnDown()
    {
        state = 1;
        
    }
}
