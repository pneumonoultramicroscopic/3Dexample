﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

    static public bool GameOver = false;

	
	// Update is called once per frame
	void Update () {
		if (GameOver == true) // 게임 오버시 시간을 멈춤
        {
            Time.timeScale = 0;
            Debug.Log(GameController.GameOver);
        }
        else
        {
            Time.timeScale = 1;
        }

        if(PlayerControl.node_num >= 4)
        {
            Time.timeScale = 1.1f;
            UIcontrol.bonus = 1.1f;
        }else if(PlayerControl.node_num >= 9)
        {
            Time.timeScale = 1.15f;
            UIcontrol.bonus = 1.2f;
        }else if(PlayerControl.node_num >= 14)
        {
            Time.timeScale = 1.2f;
            UIcontrol.bonus = 1.4f;
        }
        else if (PlayerControl.node_num >= 19)
        {
            Time.timeScale = 1.25f;
            UIcontrol.bonus = 1.7f;
        }
        else if (PlayerControl.node_num >= 24)
        {
            Time.timeScale = 1.28f;
            UIcontrol.bonus = 2.0f;
        }
        else if (PlayerControl.node_num >= 29)
        {
            Time.timeScale = 1.3f;
            UIcontrol.bonus = 2.5f;
        }
    }
}
