﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Apple : MonoBehaviour {

    public GameObject apples;
    static public bool appleEaten = false;

    private float xpos;
    private float ypos = -0.48f;
    private float zpos;
    static public bool appleInstantiated = false;

    static public float Ax;
    static public float Az;

    void Update()
    {
        if(appleEaten == false && appleInstantiated == false)
        {
            xpos = (int)Random.Range(-9.99f, 9.99f);
            zpos = (int)Random.Range(-9.99f, 9.99f);
            Ax = xpos;
            Az = zpos;
            GameObject BlueApple = Instantiate(apples) as GameObject;
            BlueApple.transform.position = new Vector3(xpos, ypos, zpos);
            appleInstantiated = true;
        }
        if(appleEaten == true)
        {
            GameObject.Destroy(GameObject.Find("Apple(Clone)"));
        }
    }
}
