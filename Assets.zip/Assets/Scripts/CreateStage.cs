﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateStage : MonoBehaviour {

    public GameObject line;
    public GameObject stage;

    private void Awake()
    {
        for(int i = 0 ; i<21 ; i++) // Make Vertical Lines
        {
            GameObject lines = Instantiate(line) as GameObject;
            lines.name = "linev" + "(" + i + ")";
            lines.transform.SetParent(stage.transform);
            lines.transform.localScale = new Vector3(1.0f, 1.0f, 0.005f);
            lines.transform.localPosition = new Vector3( 0, 0.004f, (0.05f)*(i - 10) );
        }
        for (int i = 0; i < 21; i++) // Make Horizontal Lines
        {
            GameObject lines = Instantiate(line) as GameObject;
            lines.name = "lineh" + "(" + i + ")";
            lines.transform.SetParent(stage.transform);
            
            lines.transform.localScale = new Vector3(1.0f, 1.0f, 0.005f);
            lines.transform.localRotation = Quaternion.Euler(0, 90, 0);
            lines.transform.localPosition = new Vector3((0.05f) * (i - 10), 0.004f, 0);
            
        }
    }
}
