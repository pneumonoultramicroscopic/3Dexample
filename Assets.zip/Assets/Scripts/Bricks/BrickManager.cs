﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrickManager : MonoBehaviour {

    public GameObject brick;

	// Use this for initialization
    /*
	void Start () {
        for (int i = 0; i<4; i++)
        {
            for (int j = 0; i < 10; j++)
            {
                GameObject Bricks = Instantiate(brick) as GameObject;
                Bricks.transform.position = new Vector3( -5 + j , 5 - (0.3f*i) ,0);
            }
        }
    }*/
	
	
}
