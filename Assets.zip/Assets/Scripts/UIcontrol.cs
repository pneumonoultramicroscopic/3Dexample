﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIcontrol : MonoBehaviour {

    public Text score;
    public Text node;
    public Text highscore;

    static public float bonus = 1.0f;
    static public int movebonus = 0;
    static public int sc = 0;

    private void Start()
    {
        highscore.text = PlayerPrefs.GetInt("HighScore", 0).ToString();
    }

    // Update is called once per frame
    void Update () {
        sc = PlayerControl.node_num * (int)(10 * bonus) + movebonus;
        score.text = sc.ToString();
        node.text = (PlayerControl.node_num + 1).ToString();
	}

    public void ToMenu()
    {
        GameController.GameOver = false;
        Application.LoadLevel("MainScene"); 
        Debug.Log(GameController.GameOver);
    }
    
    public void ToGame()
    {
        Application.LoadLevel("Snake3D_Game");
        movebonus = 0;
        bonus = 1.0f;
        PlayerControl.node_num = 0;
        Apple.appleEaten = false;
        Apple.appleInstantiated = false;
    }

    public void ToHighScore()
    {
        Application.LoadLevel("HighScoreScene");
    }
    public void EndGame()
    {
        Application.Quit();
    }
}
